// src/config/socket.js
// ─────────────────────────────────────────────────────────────────────────────
// WHY THIS FILE EXISTS:
//   Socket.IO needs access to the HTTP server (not just Express app).
//   We initialize it here and export a helper to get the io instance
//   from anywhere in the app without passing it around manually.
// ─────────────────────────────────────────────────────────────────────────────

const { Server } = require("socket.io");

let io; // Will hold our Socket.IO instance

const initSocket = (httpServer) => {
  // Create a new Socket.IO server attached to our HTTP server
  // cors: allow all origins in development (restrict in production)
  io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  // io.on('connection') fires every time a new client connects
  io.on("connection", (socket) => {
    console.log(`⚡ Socket connected: ${socket.id}`);

    // 'joinProject' — client sends this to join a project room
    // All users viewing the same project join the same room
    // This lets us broadcast task updates to everyone in that project
    socket.on("joinProject", (projectId) => {
      socket.join(`project:${projectId}`);
      console.log(`📌 Socket ${socket.id} joined room: project:${projectId}`);
    });

    // 'leaveProject' — client sends this when leaving a project view
    socket.on("leaveProject", (projectId) => {
      socket.leave(`project:${projectId}`);
    });

    // 'joinUser' — client sends their userId to join a PERSONAL room
    // This is used for direct notifications (e.g., "you were assigned a task")
    // Each user has their own private room: user:{userId}
    // When tasks.service.js does io.to(`user:${assigneeId}`).emit(...)
    // only that specific user receives it
    socket.on("joinUser", (userId) => {
      socket.join(`user:${userId}`);
      console.log(
        `👤 Socket ${socket.id} joined personal room: user:${userId}`,
      );
    });

    // 'leaveUser' — client sends this on logout
    socket.on("leaveUser", (userId) => {
      socket.leave(`user:${userId}`);
    });

    // 'disconnect' fires when a client closes the browser or loses connection
    socket.on("disconnect", () => {
      console.log(`🔌 Socket disconnected: ${socket.id}`);
    });
  });

  return io;
};

// getIO() lets other files (like task controller) emit events
// without needing to import the HTTP server
const getIO = () => {
  if (!io) throw new Error("Socket.IO not initialized!");
  return io;
};

module.exports = { initSocket, getIO };
