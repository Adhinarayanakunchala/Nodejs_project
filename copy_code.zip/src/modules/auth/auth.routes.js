// src/modules/auth/auth.routes.js
// ─────────────────────────────────────────────────────────────────────────────
// Routes:
//   POST /api/auth/register  → create account, returns JWT token
//   POST /api/auth/login     → login, returns JWT token
//   GET  /api/auth/me        → get current user (protected)
//
// NOTE: We use simple manual validation instead of express-validator
// to avoid Express 5 compatibility issues. This is cleaner and easier to understand.
// ─────────────────────────────────────────────────────────────────────────────

const express = require("express");
const { register, login, getMe } = require("./auth.controller");
const { protect } = require("../../middleware/auth");

const router = express.Router();

// ── Routes ────────────────────────────────────────────────────────────────────
router.post("/register", register);
router.post("/login", login);
router.get("/me", protect, getMe);

module.exports = router;
